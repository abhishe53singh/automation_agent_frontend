"""Probe: list every documented operation via the OpenAPI schema.

FastAPI 0.141 keeps `include_router` as nested `_IncludedRouter` wrappers, so
`app.routes` is no longer a flat list of APIRoutes; the OpenAPI document is the
reliable inventory of what the app actually exposes.
"""

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from main import app


schema = app.openapi()

operations = []

for path, methods in schema["paths"].items():

    for method, operation in methods.items():

        if method not in ("get", "post", "put", "patch", "delete"):

            continue

        operations.append(
            (
                path,
                method.upper(),
                operation.get("tags", []),
                "SECURED" if operation.get("security") else "public",
            )
        )

print("OPERATION_COUNT:", len(operations))

for path, method, tags, secured in sorted(operations):

    print(f"{method:6} {path:62} {secured:8} {','.join(tags)}")

