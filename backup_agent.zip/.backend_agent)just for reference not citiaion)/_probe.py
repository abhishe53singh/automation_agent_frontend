"""Throwaway DB capability probe (run, read output, then delete)."""

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from sqlalchemy import text

from app.db.session import engine


with engine.connect() as conn:

    print("PG_VERSION:", conn.execute(text("show server_version")).scalar())

    print(
        "VECTOR_AVAILABLE:",
        conn.execute(
            text(
                "select count(*) from pg_available_extensions"
                " where name = 'vector'"
            )
        ).scalar(),
    )

    print(
        "VECTOR_INSTALLED:",
        conn.execute(
            text(
                "select count(*) from pg_extension where extname = 'vector'"
            )
        ).scalar(),
    )

    print(
        "ALEMBIC_HEAD:",
        conn.execute(
            text("select version_num from alembic_version")
        ).fetchall(),
    )

    print(
        "TABLES:",
        sorted(
            row[0]
            for row in conn.execute(
                text(
                    "select tablename from pg_tables"
                    " where schemaname = 'public'"
                )
            )
        ),
    )
